import React from 'react';
import { Route, BrowserRouter } from 'react-router-dom';
import Loginpage from './components/Loginpage';
import dashboard from './components/sideBar/index';
import Profile from './components/Settings/Profile/index';
import Api from './components/Settings/Api/index';

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <div className="sans-serif">
          <Route exact path="/" component={Loginpage} />
          <Route path="/dashboard" component={dashboard} />
          <Route path="/account/settings" component={Profile} />
          <Route path="/account/api" component={Api} />
        </div>
      </BrowserRouter>
    </div>
  );
}

export default App;
