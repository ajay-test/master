import React from 'react';
import {Link} from 'react-router-dom';
import { Divider } from '@material-ui/core';
import Typography from '@material-ui/core/Typography';
import logo from '../../../assets/images/logo.png';
import usericon from '../../../assets/images/user.png';
import logouticon from '../../../assets/images/logout.png';
import flagicon from '../../../assets/images/flag.png';
import '../../../styles/sidebar/_sidebar.scss';


export default function ProfileDrawer(props) {
  return (
    <div style={{width: '100%', height: '100%'}}>
      <header style={{width: '100%', height: '13%', padding: '0px 8px 16px 16px'}}>
        <a href="/dashboard"><img src={logo} className="icon-imag" alt="Logo" /></a>
        <img src={flagicon} className="flag-icon-imag" alt="flagicon" />
        <h6 className="flag-text">US</h6>
      </header>
      <div style={{width: '100%'}}>
        <div style={{
          width: '95%', height: '15%', marginLeft: '5px', marginRight: '5px'
        }}>
          <Typography component={Link} to="/dashboard" style={{color: 'gray'}}>
Dashboard
          </Typography>
        </div>
        <br />
        <div style={{
          width: '95%', height: '15%', marginLeft: '5px', marginRight: '5px'
        }}>
          <Typography component={Link} to="/inbox" style={{color: 'gray'}}>
Inbox
          </Typography>
        </div>
        <br />
        <div style={{
          width: '95%', height: '15%', marginLeft: '5px', marginRight: '5px'
        }}>
          <Typography component={Link} to="/campaigns" style={{color: 'gray'}}>
Campaigns
          </Typography>
        </div>
        <br />
        <div style={{
          width: '95%', height: '15%', marginLeft: '5px', marginRight: '5px'
        }}>
          <Typography component={Link} to="/autoresponders" style={{color: 'gray'}}>
Autoresponders
          </Typography>
        </div>
        <br />
        <div style={{
          width: '95%', height: '15%', marginLeft: '5px', marginRight: '5px'
        }}>
          <Typography component={Link} to="/keywords" style={{color: 'gray'}}>
Keywords
          </Typography>
        </div>
        <br />
        <div style={{
          width: '95%', height: '15%', marginLeft: '5px', marginRight: '5px'
        }}>
          <Typography component={Link} to="/subscribers" style={{color: 'gray'}}>
Subscribers
          </Typography>
        </div>
        <br />
        <div>
          <Typography component={Link} to="/help" style={{color: 'gray'}}>
Help
          </Typography>
        </div>
        <div style={{marginTop: '100px'}}>
          <img src={usericon} className="user-icon-image" alt="addicon" />
          <div className="dropdown">
            <h4 className="dropbtn" style={{margin: '0px 0px 0px 10px'}}>Peachy King</h4>
            <div className="dropdown-content">
              <h5 style={{
                margin: '8px 0px 2px 10px', color: '#707a89'
              }}>
                {' '}
                  clayton@leadjar.io
                {' '}
              </h5>
              <div>
                <Typography component={Link} to="/account/settings" style={{display: 'inline-block'}}>
                  <img src={usericon} className="profile-icon-image" alt="addicon" />
                  <spam>Profile & Settings</spam>
                </Typography>
              </div>
              <Divider />
              <div>
                <Typography component={Link} to="/" style={{display: 'inline-block'}}>
                  <img src={logouticon} className="logout-icon-image" alt="logout" />
                  <spam> Logout </spam>
                </Typography>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
