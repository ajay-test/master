/* eslint-disable react/button-has-type */
import React from 'react';
import AppBar from '@material-ui/core/AppBar';
import CssBaseline from '@material-ui/core/CssBaseline';
import Drawer from '@material-ui/core/Drawer';
import Hidden from '@material-ui/core/Hidden';
import IconButton from '@material-ui/core/IconButton';
import MenuIcon from '@material-ui/icons/Menu';
import Toolbar from '@material-ui/core/Toolbar';
import Typography from '@material-ui/core/Typography';
import { makeStyles, useTheme } from '@material-ui/core/styles';
import { Container, Row, Col } from 'reactstrap';
import message from '../../assets/images/message-icon.png';
import SidebarData from './SidebarData/index';
import Phonenumber from '../Dashboard/phonenum';
import Inbox from '../Dashboard/inbox';
import Progress from '../Dashboard/progress';
import MessageChart from '../Dashboard/messagechart';
import '../../styles/sidebar/_sidebar.scss';

const drawerWidth = 240;

const useStyles = makeStyles(theme => ({
  appBar: {
    marginLeft: drawerWidth,
    backgroundColor: 'white',
    [theme.breakpoints.up('sm')]: {
      width: `calc(100% - ${drawerWidth}px)`,
    },
  },
  menuButton: {
    marginRight: theme.spacing(2),
    [theme.breakpoints.up('sm')]: {
      display: 'none',
    },
  },
  toolbar: theme.mixins.toolbar,
  drawerPaper: {
    width: drawerWidth,
    backgroundColor: '#e0e8ee'
  },
  content: {
    flexGrow: 1,
    backgroundColor: theme.palette.background.default,
    padding: theme.spacing(3),
  },
}));

export default function ResponsiveDrawer(props) {
  const { container } = props;
  const classes = useStyles();
  const theme = useTheme();
  const [mobileOpen, setMobileOpen] = React.useState(false);

  function handleDrawerToggle() {
    setMobileOpen(!mobileOpen);
  }

  return (
    <div className="root">
      <CssBaseline />
      <AppBar position="fixed" className={classes.appBar}>
        <Toolbar>
          <IconButton
            color="inherit"
            aria-label="Open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            className={classes.menuButton}
          >
            <MenuIcon />
          </IconButton>
          <Typography style={{color: 'black'}} variant="h6" noWrap>
            Dashboard
          </Typography>
          <img src={message} className="icon-imag2" alt="Logo" />
        </Toolbar>
      </AppBar>
      <nav className="drawer" aria-label="Mailbox folders">
        {/* The implementation can be swapped with js to avoid SEO duplication of links. */}
        <Hidden smUp implementation="css">
          <Drawer
            container={container}
            variant="temporary"
            anchor={theme.direction === 'rtl' ? 'right' : 'left'}
            open={mobileOpen}
            onClose={handleDrawerToggle}
            classes={{
              paper: classes.drawerPaper,
            }}
            ModalProps={{
              keepMounted: true, // Better open performance on mobile.
            }}
          >

            drawer
          </Drawer>
        </Hidden>
        <Hidden xsDown implementation="css">
          <Drawer
            classes={{
              paper: classes.drawerPaper,
            }}
            variant="permanent"
            open
          >
            <SidebarData />
          </Drawer>
        </Hidden>
      </nav>
      <div style={{
        marginLeft: '15.5%', marginTop: '4.3%', width: '83%', height: '100%', backgroundColor: '#eff3f6'
      }}>
        <Container style={{marginTop: '0%', padding: '0px 0px 0px 0px'}}>
          <Row>
            <Col xs="9" style={{padding: '0px 0px 0px 0px', marginTop: '2%'}}><Progress /></Col>
            <Col xs="3" style={{padding: '0px 0px 0px 0px', marginTop: '2%'}}><Phonenumber /></Col>
          </Row>
        </Container>
        <Container style={{padding: '0px 0px 0px 0px'}}>
          <Row>
            <Col xs="9" style={{padding: '0px 0px 0px 0px', marginTop: '2%'}}><MessageChart /></Col>
            <Col xs="3" style={{padding: '0px 0px 0px 0px', marginTop: '2%'}}><Inbox /></Col>
          </Row>
        </Container>
      </div>
    </div>
  );
}
