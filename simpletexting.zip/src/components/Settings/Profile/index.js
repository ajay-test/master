/* eslint-disable react/button-has-type */
import React from 'react';
import {Link} from 'react-router-dom';
import { Divider } from '@material-ui/core';
import Button from '@material-ui/core/Button';
import closeicon from '../../../assets/images/close.png';
import AccountBox from './accountBox/index';
import '../../../styles/settings/_settings.scss';


export default function ProfileDrawer(props) {

  return (
    <div>
      <div>
        <header className="setting-main">
          <div className="setting-first">
            <img src={closeicon} className="close-icon-image" alt="closeicon" />
            <spam style={{fontSize: '20px'}}> Settings </spam>
          </div>
          <div className="profile">
            <Button component={Link} to="/account/settings">Profile</Button>
            <Button component={Link} to="/account/api" style={{display: 'inline-block'}}>Api</Button>
          </div>
        </header>
        <Divider />
        <div className="mainBox">
          <div className="innerBox">
            <AccountBox />
          </div>
        </div>
      </div>
    </div>
  );
}
