/* eslint-disable jsx-a11y/label-has-associated-control */
/* eslint-disable react/button-has-type */
import React from 'react';
import usericondefult from '../../../../../assets/images/userdefult-icon.png';
import '../../../../../styles/settings/_settings.scss';


export default function ResponsiveDrawer(props) {

  return (
    <div>
      <div>
        <img src={usericondefult} alt="closeicon" style={{width: '120px', height: '120px', margin: '10px 10px 10px 40px'}} />
      </div>
    </div>
  );
}
