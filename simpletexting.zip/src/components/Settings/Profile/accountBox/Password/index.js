/* eslint-disable react/button-has-type */
/* eslint-disable jsx-a11y/label-has-associated-control */
import React from 'react';
import closealerticon from '../../../../../assets/images/closealert.png';
import '../../../../../styles/settings/_password.scss';


export default function ResponsiveDrawer(props) {

  return (
    <div className="main">
      <div className="passmain">
        <div style={{width: '100%', height: '19px'}}>
          <img src={closealerticon} className="close-icon-image" alt="closeicon" />
          <h5 className="texth5">
          Password Strength
          </h5>
        </div>
        <br />
        Use at least 8 characters, with at least one uppercase letter, one lowercase letter, and one number. Don't use a password from another site or something too obvious.
      </div>
      <div className="oldPassword">
        <div className="password-main">
          <label className="passwordlebal">Old password</label>
          <br />
          <div className="inputdiv">
            <input
              type="text"
              className="inputpassword" />
          </div>
        </div>
        <div className="password-main">
          <label className="passwordlebal">New password</label>
          <br />
          <div className="inputdiv">
            <input
              type="text"
              className="inputpassword" />
          </div>
        </div>
        <div className="password-main">
          <label className="passwordlebal">Confirm new password</label>
          <br />
          <div className="inputdiv">
            <input
              type="text"
              className="inputpassword" />
          </div>
        </div>
        <div
          className="buttondiv">
          <button
            className="buttonmain">
          Update password
          </button>
        </div>
      </div>
    </div>
  );
}
