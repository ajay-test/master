/* eslint-disable react/button-has-type */
/* eslint-disable jsx-a11y/label-has-associated-control */
import React from 'react';
import Tooltip from '@material-ui/core/Tooltip';
import questionicon from '../../../../../assets/images/question.png';
import '../../../../../styles/settings/_Webhooks.scss';


export default function ResponsiveDrawer(props) {

  return (
    <div className="main">
      <div className="passmain">
        <div style={{width: '100%', height: '19px'}}>
          <h5 style={{color: 'black'}}>
          Configure Webhooks
          </h5>
        </div>
        <br />
        Use webhooks to communicate between the SimpleTexting platform and your server. Enter the URLs you’d like to invoke calls to to below. SimpleTexting will trigger webhooks for new incoming messages, delivery reports and unsubscribes. Now you can build scripts that interpret and respond to events that occur in your SimpleTexting account!
        <div style={{marginTop: '10px'}}>Find the full documentation for webhooks under the Documentation tab.</div>
      </div>
      <div className="oldPassword">
        <div className="password-main" style={{marginTop: '10px'}}>
          <label className="passwordlebal">
        SMS FORWARDING URL
            {' '}
            <Tooltip className="d-inline-block" id="tooltip-top-start" title="Triggers when a new incoming SMS is received. Sent as GET." placement="top-start">
              <img src={questionicon} className="question-image" alt="closeicon" />
            </Tooltip>
          </label>
          <br />
          <div className="inputdiv">
            <input
              type="text"
              className="inputSms" />
          </div>
        </div>
        <div className="password-main">
          <label className="passwordlebal">
          MMS FORWARDING URL
            {' '}
            <Tooltip className="d-inline-block" id="tooltip-top-start" title="Triggers when a new incoming MMS is received. Sent as POST." placement="top-start">
              <img src={questionicon} className="question-image" alt="closeicon" />
            </Tooltip>
          </label>
          <br />
          <div className="inputdiv">
            <input
              type="text"
              className="inputSms" />
          </div>
        </div>
        <div className="password-main">
          <label className="passwordlebal">
          DELIVERY REPORT URL
            {' '}
            <Tooltip className="d-inline-block" id="tooltip-top-start" title="Triggers when an outgoing message is reported as delivered or undelivered. Only for messages sent via public API. Sent as POST." placement="top-start">
              <img src={questionicon} className="question-image" alt="closeicon" />
            </Tooltip>
          </label>
          <br />
          <div className="inputdiv">
            <input
              type="text"
              className="inputSms" />
          </div>
        </div>
        <div className="password-main">
          <label className="passwordlebal">
          UNSUBSCRIBE REPORT URL
            {' '}
            <Tooltip className="d-inline-block" id="tooltip-top-start" title="Triggers when a contact unsubscribes. Sent as POST." placement="top-start">
              <img src={questionicon} className="question-image" alt="closeicon" />
            </Tooltip>
          </label>
          <br />
          <div className="inputdiv">
            <input
              type="text"
              className="inputSms" />
          </div>
        </div>
        <div
          className="buttondiv">
          <button
            className="buttonmain">
          Save changes
          </button>
        </div>
      </div>
    </div>
  );
}
