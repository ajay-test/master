import React from 'react';
import {NativeSelect} from '@material-ui/core';
import '../../../../../styles/settings/_api.scss';

const TimeDuration = ['Current Billing Cycle', 'Last Billing Cycle', 'Last 7 Days', 'Last 30 Days', 'Last 90 Days', 'Custom'];

export default function ResponsiveDrawer(apiData) {
  const [value, setValue] = React.useState('Current Billing Cycle');

  function handleChange(event, newValue) {
    setValue(newValue);
  }

  return (
    <div>
      <div style={{width: '100%', height: '30%'}}>
        <NativeSelect
          id="apitransaction"
          name="apitransaction"
          variant=""
          className="dropdown-menu"
          value={apiData.apitransaction}
          onChange={handleChange}
        >
          {TimeDuration.map(option => (
            <option value={option}>
              {option}
            </option>
          ))}
        </NativeSelect>
        <input className="input-menu" type="taxt" placeholder="Search by phone" />
      </div>
      <div style={{
        textAlign: 'center', color: 'gray', marginTop: '10px'
      }}>
Nothing found
      </div>
    </div>
  );
}
