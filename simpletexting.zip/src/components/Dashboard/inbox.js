import React from 'react';
import Typography from '@material-ui/core/Typography';
import {Link} from 'react-router-dom';
import '../../styles/dashBoard/_inbox.scss';

export default function ProgressBar(props) {

  return (
    <div style={{
      width: '100%', height: '372px', backgroundColor: 'white', border: '1px solid rgba(0,27,72,.32)', borderRadius: '4px', padding: '8px 16px 8px 16px'
    }}>
      <div>
        <div style={{width: '100%', height: '24px', color: 'black'}}>
          <div>
            <Typography component={Link} to="/inbox" style={{color: '#2399f0'}}>
Inbox
            </Typography>
          </div>
          <div style={{margin: '15px 0px 0px 0px'}}>
            <input className="input-Search" type="taxt" placeholder="Search" />
          </div>
        </div>
      </div>
    </div>
  );
}
