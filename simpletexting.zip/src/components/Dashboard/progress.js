/* eslint-disable jsx-a11y/label-has-associated-control */
/* eslint-disable react/button-has-type */
import React from 'react';


export default function ProgressBar(props) {

  return (
    <div style={{
      width: '98%', height: '97px', backgroundColor: 'white', border: '1px solid rgba(0,27,72,.32)', borderRadius: '4px'
    }}>
      <div style={{
        width: '100%', height: '24px', marginBottom: '8px'
      }} />
      <div style={{marginLeft: '10px'}}>
        <div style={{
          height: '17px', width: '96%', backgroundColor: '#c8cedb'
        }}>
          <div style={{height: '17px', width: '95%', backgroundColor: '#2399f0'}} />
        </div>
        <div style={{marginTop: '3px'}}>
          <div style={{width: 'auto', height: '24px', color: 'black'}} className="float-left">
            <span>802</span>
            <span style={{color: '#a2a6ba', marginLeft: '3px'}}>Total remaining credits </span>
          </div>
          <div
            style={{
              width: 'auto', height: '24px', color: 'black', marginLeft: '2%'
            }}
            className="float-left">
            <span>11</span>
            <span style={{color: '#a2a6ba', marginLeft: '3px'}}>Credits used </span>
          </div>
        </div>
      </div>
    </div>
  );
}
