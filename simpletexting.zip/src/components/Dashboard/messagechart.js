import React from 'react';
import { Container, Row, Col } from 'reactstrap';
import 'bootstrap/dist/css/bootstrap.min.css';


export default function ProgressBar(props) {

  return (
    <div style={{width: '100%', height: '100%'}}>
      <div style={{
        width: '98%', height: '372px', border: '1px solid rgba(0,27,72,.32)', backgroundColor: 'white', borderRadius: '4px'
      }}>
        <div style={{width: '100%', height: '20px'}}>
          <div style={{width: '35.7%', marginLeft: '20px'}} />
          <div className="row">
            <div className="col">
              1 of 2
            </div>
            <div className="col">
             2 of 2
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
