import React from 'react';

export default function ProgressBar(props) {

  return (
    <div style={{
      width: '100%', height: '97px', backgroundColor: 'white', border: '1px solid rgba(0,27,72,.32)', borderRadius: '4px', padding: '8px 16px 8px 16px'
    }}>
      <div>
        <div style={{width: '100%', height: '24px', color: 'black'}}>
          <div style={{color: 'black'}}><b>Your phone number</b></div>
          <div style={{margin: '15px 0px 0px 0px'}}>
            <h6 style={{color: 'gray'}}>8446177746</h6>
          </div>
        </div>
      </div>
    </div>
  );
}
