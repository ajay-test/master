/* eslint-disable react/destructuring-assignment */
/* eslint-disable react/void-dom-elements-no-children */
import React from 'react';
import {Link} from 'react-router-dom';
import Checkbox from '@material-ui/core/Checkbox';
import Button from '@material-ui/core/Button';
import FormControlLabel from '@material-ui/core/FormControlLabel';
import '../../styles/pages/_login.scss';

class LoginPage extends React.Component {
  constructor() {
    super();
    this.state = {
      email: '',
      password: '',
      // eslint-disable-next-line react/no-unused-state
      checkedB: true
    };
  }

  // eslint-disable-next-line consistent-return
  handleSubmit=() => {
    if (this.state.email.length === 0 && this.state.password.length === 0) {
      alert('Wrong username or password.');
    } else {
      this.props.history.push('/dashboard');
    }
  }


  render() {
    const {
      email,
      password,
      checkedB
    } = this.state;
    return (
      <div style={{width: '100%', height: '100%'}}>
        <div className="login-content">
          <div style={{padding: '10px 10px 10px 10px'}}>
            <form>
              <h6 className="logintitle">Log in to SimpleTexting </h6>
              <div className="form-group">
                <input
                  name="email"
                  id="email"
                  onChange={event => this.setState({email: event.target.value})}
                  className="textField"
                  placeholder="Email"
                  type="email" />
                <input
                  name="password"
                  id="password"
                  onChange={event => this.setState({password: event.target.value})}
                  className="textField"
                  placeholder="Password"
                  type="password" />
              </div>
              <Button style={{marginTop: '5%'}} color="primary" variant="contained" onClick={() => this.handleSubmit()} className="loginButton">
              Log in
              </Button>
              <div className="CheckBox">
                <FormControlLabel
                  control={(
                    <Checkbox
                      checked={checkedB}
                      value="checkedB"
                      color="primary"
                      inputProps={{
                        'aria-label': 'secondary checkbox',
                      }}
                    />
                  )}
                  label="Keep me signed in"
                />
              </div>
              <div
                className="singin"
               >
                <Link to="/dashboard">
                Sign up
                </Link>
                   or log in with
              </div>
              <div className="loginSocial">
                <Button color="primary" variant="contained" style={{backgroundColor: '#3a5891'}} component={Link} to="/" className="loginfacebook">
              facebook
                </Button>
                <Button style={{marginLeft: '10px', backgroundColor: 'red'}} component={Link} to="/" className="logingoogle">
              google
                </Button>
              </div>
            </form>
          </div>
        </div>
      </div>
    );
  }
}

export default LoginPage;
